import structure5.*;
import java.util.Iterator;
import java.util.Scanner;
/* A trie class
 * (c) Landon Marchant 2017
 * Worked with TA's/TA sessions, office hours with Bill^2
 */

public class LexiconTrie implements Lexicon {

    LexiconNode root;
    int count;
    boolean isWord;

    public LexiconTrie(){
        root = new LexiconNode(' ', true);
        count = 0;
    }
    /* A method to help addWord. Takes a String and LexiconNode.
     *
     */
    protected boolean addHelper(String word, LexiconNode ln){

        LexiconNode firstChar;
        if (word.length() == 0){
            ln.setIsWord(true);
            return true;
        }
        else {
                if (ln.getChild(word.charAt(0)) == null){
                    firstChar = new LexiconNode(word.charAt(0), false);
                   // System.out.println(firstChar.letter());
                    ln.addChild(firstChar);
                   return addHelper(word.substring(1), firstChar);
                }
                else {
                    firstChar = ln.getChild(word.charAt(0));
                   // System.out.println(firstChar.letter());
                   return addHelper(word.substring(1), firstChar);

                }


        }
    }
/* Adds a String word  to the LexiconTri */
public boolean addWord(String word) {

    if (containsWord(word)){
        return false;
    }
    else {
        addHelper(word, root);
        count++;
        return true;
    }

    }

/* Adds a file of words to the LexiconTri */
    public int addWordsFromFile(String filename) {
        Scanner input = new Scanner(new FileStream(filename));
        // while input has a next token
        while (input.hasNext()){
            // make each tokem into a string
            String words = input.next();
            // lowercase each one
            words = words.toLowerCase();
            // call addWord on words
            addWord(words);
            // increase count
            count++;
        }

        return 0;
    }
/* Removes a String word from the LexiconTri */
    public boolean removeWord(String word) {
        String wordLetters = word.toLowerCase();
        // for character letter in word.toLowerCase
        LexiconNode finger = root;
        //System.out.println(finger);
        for (int i=0; i < wordLetters.length(); ++i){
            // if root children
            if (finger.getChild(wordLetters.charAt(i)) == null){
                return false;
            }
            else {
                finger = finger.getChild(wordLetters.charAt(i));
               // System.out.println(finger);
            }

        }
        if (finger.isWord()) {
            finger.setIsWord(false);
            count --;
            return true;
        }
        else {
            return false;
        }
    }
/* returns the number of words in the LexiconTri */
    public int numWords() {
        return count;
    }
/* Whether or not the LexiconTri contains a String word */

    public boolean containsWord(String word){
        String wordLetters = word.toLowerCase();

        LexiconNode finger = root;
        //System.out.println(finger);
        for (int i=0; i < wordLetters.length(); ++i){

            if (finger.getChild(wordLetters.charAt(i)) == null){
                return false;
            }
            else {
                finger = finger.getChild(wordLetters.charAt(i));
            }

        }
        return finger.isWord();
    }


/* Whether or not the LexiconTri contains a String prefix */
    public boolean containsPrefix(String prefix){
        // set everything to lowercase
        String wordLetters = prefix.toLowerCase();
        // for character letter in word.toLowerCase
        LexiconNode finger = root;
        //System.out.println(finger);
        for (int i=0; i < wordLetters.length(); ++i){
            // if root children
            if (finger.getChild(wordLetters.charAt(i)) == null){
                return false;
            }
            else {
                finger = finger.getChild(wordLetters.charAt(i));
               // System.out.println(finger);
            }

        }
        return true;
    }

/* Initializes iterator. Iterates over a vector of strings, containing words in LexiconTrie*/
    public Iterator<String> iterator() {
        // make vector
        Vector<String> LexiconWords = new Vector<String>();
        // recursion magic add things to vector
        iteratorHelper(root, "", LexiconWords);
        // return iterator
        return LexiconWords.iterator();
    }
    /* Creates iterator. Iterates over a vector of strings, containing words in LexiconTrie*/

    private void iteratorHelper(LexiconNode ln, String wordPath, Vector<String> LexiconWords) {


        if (ln.isWord()){
            //add to vectorr
            LexiconWords.add(wordPath);
        }
        // base case with no children at all
        if (ln.childrenVector.isEmpty()){
            return;
        }
        else {
            Iterator<LexiconNode> iter = ln.iterator();
            // either in base case or keep going
            while (iter.hasNext()){
                LexiconNode nextNode = iter.next();
                iteratorHelper(nextNode, wordPath+nextNode.letter(), LexiconWords);
            }
        }
    }


    public Set<String> suggestCorrections(String target, int maxDistance) {return null;}
    public Set<String> matchRegex(String pattern){return null;}
}