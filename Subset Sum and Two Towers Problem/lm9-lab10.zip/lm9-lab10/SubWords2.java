import structure5.*;
import java.util.Scanner;

/* SubWords2
 * (c) Landon Marchant
 * Lab 10
 * Worked with Shivam
 */

 /* SubWords uses OrderedStructure, OrderedVector, SubsetIterator, and ospd2.txt
  * Create subsets of the user input.
  * Finds, prints, and counts how many subsets of the user input word
  * are contained in the Oxford English Dictionary.
  * Best if used on words with a character count > 5. Tested on
  * pneumonoultramicroscopicsilicovolcanoconiosis, which has 53249 total subsets.
  * 123 of those are also words in the Oxford English Dictionary.
  */
public class SubWords2 {

    public static void addWordsFromFile(String filename, OrderedStructure<String> dictionary) {
        // add words from a source file
        Scanner input = new Scanner(new FileStream(filename));
        // while input has a next value
        while (input.hasNext()){
            // make each value into a string. Strip to lowercase.
            String words = input.nextLine().toLowerCase();
            // when we hit an empty string, break
            if (words.equals("")){
                break;
            }
            // add strings to the dictionary structure.
                dictionary.add(words);
        }
    }

    public static void main(String[] args) {
        int countWords = 0;
        int subsetCount = 0;

        // build an empty dictionary
        // add words from file, to dictionary

        OrderedVector<String> dictionary = new OrderedVector<String>();
        addWordsFromFile("ospd2.txt", dictionary);

        // Subset iterator needs a vector to work with.
        Vector<String> wordHolder = new Vector<String>();

        // we get our word to subset from the command line
        String word = args[0];

        // iterate through the word and add each substring to the wordHolder vector
        for (int i = 0; i < word.length(); i++){
            wordHolder.add(word.substring(i, i+1));
        }
        // subset iterator builds sub-words of args[0] (word)
        SubsetIterator<String> iter = new SubsetIterator<String>(wordHolder);
        // while there is a next sub-word in our iterator
        // build another sub-word and see if it's a word
        while (iter.hasNext()){
            String charString = "";

            // current subword
            Vector<String> current = iter.next();
            // append to charString, which is string version of current
            // increment count of total substrings
            for (String letter : current){
                charString += letter;
                subsetCount++;
            }
            // if the dictionary contains the string we've built
            // increment the count of total words
            if (dictionary.contains(charString)){
                countWords++;

            }
        }
                // print the total subsets of input word
                // print how many of those subsets are also words

                System.out.println("there are " + subsetCount + " total subsets of "+ word);
                System.out.println(countWords + " subsets of " + word +
                    " are in the Oxford English Dictionary.");




    }



}