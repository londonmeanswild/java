import structure5.*;
import java.util.Iterator;
/* A LexiconNode class
 * (c) Landon Marchant 2017
 * Worked with TA's/TA sessions, office hours with Bill^2
 */

class LexiconNode implements Comparable <LexiconNode>{

    protected Vector<LexiconNode> childrenVector;


    private char letter;
    private boolean isWord;


    /*
    Initializes node, vector, boolean.
        Each node contains:
        char letter
        boolean isWord
        Vector childrenVector
    */
        public LexiconNode(char ch, boolean b){
            letter = ch;
            childrenVector = new Vector<LexiconNode>();
            isWord = b;
        }

    /*
    toString method, prints contents.
    */
    public String toString(){
        LexiconNode contents;
        String print = "";
        System.out.print("Lexicon start\n");
        System.out.println(childrenVector);
        System.out.println("Lexicon letter here");
        return letter + "\n" + isWord;
    }


    /*
    Compare this LexiconNode to another.
    You should just compare the characters stored at the Lexicon Nodes.
     */
    public int compareTo(LexiconNode ch) {
        return ch.letter() - letter;
    }

    /*
    Return letter stored by this LexiconNode.
    */
    public char letter() {
        return letter;
    }

    /*
    Add LexiconNode child to correct position in child data structure.
    Do this with the compareTo method.
    Only add to the vector when ln - LexiconNode = 1
    */

    public void addChild(LexiconNode ln) {
        int i;
        for (i = 0; i < childrenVector.size(); ++i){
            // if the lexicon node ln comes after the char value of childVector node
            // this is comparing the "smaller" char to the "larger" char, if it's <0 we can add
            // like 'b' - 'c' < 0
            if (childrenVector.get(i).compareTo(ln) < 0){
                break;
            }
        }
        childrenVector.add(i, ln);
    }

    /*
    Get LexiconNode child for 'ch' out of child data structure
    */

    public LexiconNode getChild(char ch) {

        for ( LexiconNode ln  : childrenVector){
            if (ln.letter() == ch)
                return ln;
        }
        return null;
    }

/*
Remove LexiconNode child for 'ch' from child data structure
 */
public void removeChild(char ch) {
    for ( LexiconNode ln  : childrenVector){
        if (ln.letter() == ch);
        ln = childrenVector.remove(ln);
    }
}


/*
Iterate over children
*/
public Iterator<LexiconNode> iterator() {
    // travel through childrenVector, recursively
    return childrenVector.iterator();
}
/*
isWord method
*/
public boolean isWord(){
    return isWord;
}
/* set value of isWord
*/
public void setIsWord(boolean tf){
    isWord = tf;
    }
}
