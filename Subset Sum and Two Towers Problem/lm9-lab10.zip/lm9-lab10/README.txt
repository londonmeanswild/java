Two Towers Problem, lab 10
(c) Landon Marchant
 Worked with Shivam

1. What is the best solution to the 15-block problem?
    The best solution to the 15 block problem is 1, 2, 3, 7, 9, 14, 15
    The height of the best tower is 20.235083538734113
    It took 0m0.656 seconds to find the answer.

2. How long does it take your program to find the answer to the 20-block problem?
    20-block: 12.958 seconds to find the answer.

    21 block expected time: 20/12.958 is 1.543448063. So, I expected the run time to be 1.543448063 * 21 = 32.41 seconds. However, the
    21 block real time was 0m26.148s.

    25 block expected time: Since adding one to the blocks doubled the run time, I expected the 25 block problem to be 5x the run time, as it is adding 5 blocks. However, we've reached the point of exponential growth.
    25 block real time: 8m11.554s, or 491.554 seconds.


    * 40 block problem expected run time: is O(2^40)
    * 50 block problem expected run time: is O(2^50)

This is O(2^n) where n is the number of blocks we have.


3. This method of exhaustively checking the subsets of blocks will not work for very large problems. Consider, for example, the problem with 50 blocks: there are 250 different subsets. One approach is to repeatedly pick and evaluate random subsets of blocks (stop the computation after 1 second of elapsed time, printing the best subset found). How would you implement randomSubset, a new SubsetIterator method that returns a random subset? (Describe your strategy. You do not need to actually implement it.)
    Each block needs to be visited once, and SubsetIterator run for one second.
    Subsets generated in that one would then be stored in a vector.
    The best subset would be returned and moved to the "solution" vector.
    Repeat until a complete solution has been found.


SubWords:
longest word in english dictionary is pneumonoultramicroscopicsilicovolcanoconiosis
which has 123 subwords

Extra credit:
I wanted to use a doubly linked list but Shivam wouldn't lend me his computer so we could attack the dictionary from each end of the list. Tried binary search tree, got stack overflows, switched to OrderedVector and it worked immediately.
Searching linearly is time consuming. Using a trie allows for a far more efficient solution, because it stores relationships.

